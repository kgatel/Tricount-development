# Projet POOA

Réalisation d'un tricount en java.

Compétences utilisées :
 - RMI
 - JFrame/JPanel/JButton

Des détails sur comment lancer notre application se trouvent dans le README.txt disponible dans le répertoire Code/
